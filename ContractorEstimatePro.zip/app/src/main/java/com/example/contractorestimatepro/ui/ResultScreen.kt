package com.example.contractorestimatepro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.contractorestimatepro.domain.model.EstimateResult

@Composable
fun ResultScreen(result: EstimateResult, onBack: () -> Unit) {

    Column(Modifier.padding(16.dp)) {

        Text("Result")

        Text("Adjusted: ${result.adjustedSqft}")

        Text("Material: ${result.materialCost}")

        Text("Labor: ${result.laborCost}")

        Text("Removal: ${result.removalCost}")

        Text("Profit: ${result.profit}")

        Spacer(Modifier.height(20.dp))

        Text("TOTAL: ${result.total}", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = onBack) {
            Text("Back")
        }
    }
}
