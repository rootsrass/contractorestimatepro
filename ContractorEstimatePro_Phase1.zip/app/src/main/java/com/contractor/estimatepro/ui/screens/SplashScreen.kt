package com.contractor.estimatepro.ui.screens

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.*
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import com.contractor.estimatepro.navigation.Routes

@Composable
fun SplashScreen(navController: NavController) {
    LaunchedEffect(true) {
        delay(1000)
        navController.navigate(Routes.HOME)
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Contractor Estimate Pro")
    }
}