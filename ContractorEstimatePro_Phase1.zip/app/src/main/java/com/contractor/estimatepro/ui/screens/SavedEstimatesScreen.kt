package com.contractor.estimatepro.ui.screens

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.navigation.NavController

@Composable
fun SavedEstimatesScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Saved Estimates")
    }
}