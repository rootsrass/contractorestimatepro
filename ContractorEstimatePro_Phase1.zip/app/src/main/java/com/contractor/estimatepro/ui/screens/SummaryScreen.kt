package com.contractor.estimatepro.ui.screens

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.navigation.NavController
import com.contractor.estimatepro.navigation.Routes

@Composable
fun SummaryScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Summary")

        Button(onClick = { navController.navigate(Routes.HOME) }) {
            Text("Home")
        }
    }
}